//
//  MyVC.swift
//  Project2
//
//  Created by Steven Hayes on 2/27/20.
//  Copyright © 2020 Steven Hayes. All rights reserved.
//

import UIKit

class MyVC: UIViewController, UINavigationControllerDelegate {

    @IBOutlet weak var label1: UILabel!
    var cartSize = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        print("\(cartSize)")
        print("nailed it")
        var cartString = "\(cartSize)"
        print(cartString)
       // print((label1.text))
        //label1.text = "\(cartSize)"
        // Do any additional setup after loading the view.
        self.navigationController?.delegate = self
    }
    func navigationController(_ navigationController: UINavigationController, willShow viewController: UIViewController, animated: Bool) {
        
        print("willshow")
        
        if let pvc = viewController as? ViewController {
            pvc.cartSize = cartSize
            
            print("counter set to \(cartSize)")
        }
        
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

    @IBAction func dostuff(_ sender: Any) {
        print((label1.text))
        label1.text = "\(cartSize)"
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == "segue1" {
            
            if let svc = segue.destination as? MyVC{
                
                //if let str1 = sender as? Int{
                    
                //    svc.whatToShow = str1
                //}
                //else{
                    svc.cartSize = self.cartSize
                    
                    
                //}
            }
        }
    }
    
}
