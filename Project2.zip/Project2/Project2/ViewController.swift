//
//  ViewController.swift
//  Project2
//
//  Created by Steven Hayes on 2/27/20.
//  Copyright © 2020 Steven Hayes. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate  {

    var cartSize = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        print("\(cartSize)")
        navigationController?.navigationBar.isHidden
        // Do any additional setup after loading the view.
    }

   
    @IBAction func incrementButton(_ sender: Any) {
        cartSize = cartSize + 1
        print("\(cartSize)")
    }
    
    /*@IBAction func segueToNext(_ sender: UIButton) {
        var str = 10
        performSegue(withIdentifier: "toCategory", sender: str)
        
    }*/
    
    
    @IBAction func changeVC(_ sender: Any) {
    let vc2 = MyVC()
    
    vc2.modalPresentationStyle = .formSheet
    vc2.modalTransitionStyle = .crossDissolve
    show(vc2, sender: true)
    
    //present(vc2, animated: true)
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        print(segue.identifier)
        if segue.identifier == "toCategory" {
            
            if let svc = segue.destination as? MyVC{
                print("cart size \(cartSize)")
                svc.cartSize = self.cartSize
            }
        }
    }

}

